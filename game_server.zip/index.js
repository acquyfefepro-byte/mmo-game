const express = require('express');
const app = express();
const http = require('http').createServer(app);
const WebSocket = require('ws');

app.use(express.static('public'));

const wss = new WebSocket.Server({ server: http });

wss.on('connection', ws => {
  ws.on('message', msg => {
    wss.clients.forEach(c => {
      if (c.readyState === WebSocket.OPEN) c.send(msg.toString());
    });
  });
});

http.listen(3000, () => console.log("Server running"));