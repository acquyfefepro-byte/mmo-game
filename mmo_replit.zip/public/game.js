const socket = io();
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let players = {};
let myId = null;
const speed = 4;

socket.on("initPlayers", (data) => {
  players = data;
});

socket.on("yourId", (id) => {
  myId = id;
  // ensure our player exists (server created it)
  if (!players[myId]) {
    players[myId] = { x: 100, y: 100, name: "You" };
  }
});

socket.on("newPlayer", (data) => {
  players[data.id] = data.data;
});

socket.on("playerMoved", (data) => {
  if (players[data.id]) {
    players[data.id].x = data.x;
    players[data.id].y = data.y;
  }
});

socket.on("playerDisconnected", (id) => {
  delete players[id];
});

// keyboard movement
const keys = {};
document.addEventListener("keydown", (e) => { keys[e.key.toLowerCase()] = true; });
document.addEventListener("keyup", (e) => { keys[e.key.toLowerCase()] = false; });

function update() {
  if (myId && players[myId]) {
    let p = players[myId];
    let moved = false;
    if (keys['w'] || keys['arrowup']) { p.y -= speed; moved = true; }
    if (keys['s'] || keys['arrowdown']) { p.y += speed; moved = true; }
    if (keys['a'] || keys['arrowleft']) { p.x -= speed; moved = true; }
    if (keys['d'] || keys['arrowright']) { p.x += speed; moved = true; }
    // keep inside canvas
    p.x = Math.max(0, Math.min(canvas.width-30, p.x));
    p.y = Math.max(0, Math.min(canvas.height-30, p.y));
    if (moved) {
      socket.emit("move", { x: p.x, y: p.y });
    }
  }
}

function draw() {
  ctx.clearRect(0,0,canvas.width,canvas.height);
  // draw grid
  ctx.fillStyle = '#1b1b1b';
  for (let x=0;x<canvas.width;x+=50) ctx.fillRect(x,0,1,canvas.height);
  for (let y=0;y<canvas.height;y+=50) ctx.fillRect(0,y,canvas.width,1);

  for (let id in players) {
    let p = players[id];
    ctx.fillStyle = (id === myId) ? '#00e6ff' : '#ff5c5c';
    ctx.fillRect(p.x, p.y, 30, 30);
    ctx.fillStyle = '#fff';
    ctx.font = '12px Arial';
    ctx.fillText(p.name || id, p.x, p.y - 6);
  }
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}
loop();
