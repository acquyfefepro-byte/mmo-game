const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http, {
  cors: { origin: "*" }
});

app.use(express.static("public"));

let players = {};

io.on("connection", (socket) => {
  console.log("Player connected:", socket.id);

  // create player at random position
  players[socket.id] = {
    x: Math.floor(Math.random() * 600) + 50,
    y: Math.floor(Math.random() * 300) + 50,
    hp: 100,
    name: "Player_" + socket.id.slice(0,4)
  };

  // send full state to the new player
  socket.emit("initPlayers", players);
  // tell the new player their id
  socket.emit("yourId", socket.id);
  // tell others there's a new player
  socket.broadcast.emit("newPlayer", { id: socket.id, data: players[socket.id] });

  socket.on("move", (data) => {
    if (!players[socket.id]) return;
    players[socket.id].x = data.x;
    players[socket.id].y = data.y;
    socket.broadcast.emit("playerMoved", { id: socket.id, x: data.x, y: data.y });
  });

  socket.on("disconnect", () => {
    console.log("Player disconnected:", socket.id);
    delete players[socket.id];
    io.emit("playerDisconnected", socket.id);
  });
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
  console.log("Server running on port", PORT);
});
