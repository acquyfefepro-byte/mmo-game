MMO Replit Demo
----------------
Files:
- server.js         : Node.js + Socket.IO server
- package.json      : dependencies and start script
- public/index.html : client HTML
- public/game.js    : client JS (Canvas)

How to deploy on Replit:
1. Create a new Repl (Node.js).
2. Upload the ZIP contents or paste files into the editor.
3. Replit will run `npm install` automatically (or click the "Run" button to install).
4. Start the server with `node server.js` (Replit runs `npm start` if configured).
5. Open the Repl webview or the public URL to play. Open multiple tabs to test multiplayer.
